﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using RazorHelpers.Attributes;

namespace RazorHelpers.Models
{
    public class UserModel
    {
        [Required(ErrorMessage = "Please Enter Name")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Please Enter User Name")]
        public string Username { get; set; }
        [Required(ErrorMessage = "Please Enter Password")]
        public string Password { get; set; }
        [Required(ErrorMessage = "Please Enter Confirm Password")]
        [Compare("Password", ErrorMessage = "Confirm Password doesn't match")]
        public string ConfirmPassword { get; set; }
        [Required(ErrorMessage = "Please Enter Contact Number")]
        [RegularExpression("^[6,7,8,9]\\d{9}$",ErrorMessage = "Please Enter Valid Contact Number")]
        public string Contact { get; set; }
        [Required(ErrorMessage = "Please Select Country")]
        public string Country { get; set; }
        [Required(ErrorMessage = "Please Select City")]
        public string City { get; set; }
        [Required(ErrorMessage = "Please Enter Gender")]
        public string Gender { get; set; }
        [ValidateCheckBox(ErrorMessage = "Please Accept Terms")]
        public bool AcceptTerms { get; set; }

    }
    public class Countries
    {
        public string CountryCode { get; set; }
        public string Country { get; set; }
    }
    public class Cities
    {
        public string CityCode { get; set; }
        public string City { get; set; }
    }
}
