﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using RazorHelpers.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RazorHelpers.Controllers
{
    public class AccountController : Controller
    {
        public IActionResult Login()
        {
            return View();
        }
        //[HttpPost]
        //public IActionResult Login(string Username, string Password)
        //{
        //    return View();
        //}
        [HttpPost]
        public IActionResult Login(LoginModel model)
        {
            if (model.Username == "admin" && model.Password == "admin")
            {
                return RedirectToAction("Index", "Home");
            }
            return View();
        }
        public IActionResult SignUp()
        {
            List<Countries> Countrylist = new List<Countries>();
            Countrylist.Insert(0, new Countries { CountryCode = "", Country = "Select" });
            Countrylist.Insert(1, new Countries { CountryCode = "AF", Country = "Afghanistan" });
            Countrylist.Insert(2, new Countries { CountryCode = "BD", Country = "Bangladesh" });
            Countrylist.Insert(3, new Countries { CountryCode = "CN", Country = "China" });
            //Countrylist.Insert(4, new Countries { CountryCode = "DM", Country = "Denmark" });
            //Countrylist.Insert(5, new Countries { CountryCode = "EG", Country = "Egypt" });
            //Countrylist.Insert(6, new Countries { CountryCode = "FN", Country = "France" });
            //Countrylist.Insert(7, new Countries { CountryCode = "GM", Country = "Germany" });
            //Countrylist.Insert(8, new Countries { CountryCode = "HG", Country = "Hungary" });
            Countrylist.Insert(4, new Countries { CountryCode = "IN", Country = "India" });
            //Countrylist.Insert(10, new Countries { CountryCode = "JP", Country = "Japan" });
            //Countrylist.Insert(11, new Countries { CountryCode = "KZ", Country = "Kyrgyzstan" });
            //Countrylist.Insert(12, new Countries { CountryCode = "LS", Country = "Laos" });
            //Countrylist.Insert(13, new Countries { CountryCode = "NZ", Country = "New Zealand" });
            Countrylist.Insert(5, new Countries { CountryCode = "US", Country = "United States Of America" });
            //Countrylist.Insert(5, new Countries { CountryCode = "ZW", Country = "Zimbabwe" });

            ViewBag.ListofCountry = Countrylist;
            return View();
        }
        [HttpPost]
        public IActionResult SignUp(UserModel model)
        {
            if(ModelState.IsValid)
            {
                return RedirectToAction("Index", "Home");
            }
            return View();
        }
        public JsonResult GetCity(string Country)
        {
            List<Cities> Citylist = new List<Cities>();
            if(Country == "IN")
            {
                Citylist.Insert(0, new Cities { CityCode = "Agra", City = "Agra" });
                Citylist.Insert(1, new Cities { CityCode = "Banglore", City = "Banglore" });
                Citylist.Insert(2, new Cities { CityCode = "Chennai", City = "Chennai" });
                Citylist.Insert(3, new Cities { CityCode = "Delhi", City = "Delhi" });
                Citylist.Insert(4, new Cities { CityCode = "Faridabad", City = "Faridabad" });
                Citylist.Insert(5, new Cities { CityCode = "Gurugram", City = "Gurugram" });
                Citylist.Insert(6, new Cities { CityCode = "Noida", City = "Noida" });
                Citylist.Insert(7, new Cities { CityCode = "Kolkata", City = "Kolkata" });
                Citylist.Insert(8, new Cities { CityCode = "Mumbai", City = "Mumbai" });
            }
            else if (Country == "AF")
            {
                Citylist.Insert(0, new Cities { CityCode = "Kabul", City = "Kabul" });
            }
            else if (Country == "BD")
            {
                Citylist.Insert(0, new Cities { CityCode = "Dhaka", City = "Dhaka" });
            }
            else if (Country == "CN")
            {
                Citylist.Insert(0, new Cities { CityCode = "Beijing", City = "Beijing" });
            }
            else if (Country == "US")
            {
                Citylist.Insert(0, new Cities { CityCode = "Austin", City = "Austin" });
                Citylist.Insert(1, new Cities { CityCode = "California", City = "California" });
                Citylist.Insert(2, new Cities { CityCode = "New Jersey", City = "New Jersey" });
                Citylist.Insert(3, new Cities { CityCode = "New York", City = "New York" });
                Citylist.Insert(4, new Cities { CityCode = "Malvern", City = "Malvern" });
                Citylist.Insert(5, new Cities { CityCode = "San Fransico", City = "San Fransico" });
            }

            return Json(new SelectList(Citylist, "CityCode", "City"));
        }
    }
}
