﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RazorHelpers.Controllers
{
    public class EmployeeController : Controller
    {
        [Route("Employee/index/{id}/{deptid}")]
        [Route("Employee_dtl/index/{id}/{deptid}")]
        public IActionResult Index(int id, int deptid)
        {
            return View();
        }
    }
}
